import os
import re
import tempfile

from krita import Extension, FileDialog, InfoObject
from builtins import Application

try:
    from PyQt6.QtCore import Qt, QRect
    from PyQt6.QtGui import QImage, QPainter, QColor
    from PyQt6.QtWidgets import (
        QComboBox,
        QDialog,
        QDialogButtonBox,
        QFormLayout,
        QHBoxLayout,
        QLabel,
        QLineEdit,
        QMessageBox,
        QProgressDialog,
        QPushButton,
        QSpinBox,
        QVBoxLayout,
        QApplication,
    )
except Exception:
    from PyQt5.QtCore import Qt, QRect
    from PyQt5.QtGui import QImage, QPainter, QColor
    from PyQt5.QtWidgets import (
        QComboBox,
        QDialog,
        QDialogButtonBox,
        QFormLayout,
        QHBoxLayout,
        QLabel,
        QLineEdit,
        QMessageBox,
        QProgressDialog,
        QPushButton,
        QSpinBox,
        QVBoxLayout,
        QApplication,
    )


EXPORTABLE_TYPES = {
    "paintlayer",
    "grouplayer",
    "filelayer",
    "vectorlayer",
    "filllayer",
    "clonelayer",
}


def enum_value(owner, enum_name, value_name):
    enum_owner = getattr(owner, enum_name, owner)
    return getattr(enum_owner, value_name)


def sanitize_filename(name):
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return cleaned or "layer"


def unique_path(directory, base_name, extension):
    path = os.path.join(directory, base_name + extension)
    if not os.path.exists(path):
        return path

    index = 1
    while True:
        candidate = os.path.join(directory, "{}_{:03d}{}".format(base_name, index, extension))
        if not os.path.exists(candidate):
            return candidate
        index += 1


class ExportDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Export Selected Layers")
        self.setWindowModality(enum_value(Qt, "WindowModality", "NonModal"))

        self.directory_field = QLineEdit()
        self.directory_field.setReadOnly(True)
        self.browse_button = QPushButton("...")
        self.format_combo = QComboBox()
        self.quality_spin = QSpinBox()
        self.summary_label = QLabel("")
        standard_button = getattr(QDialogButtonBox, "StandardButton", QDialogButtonBox)
        self.button_box = QDialogButtonBox(standard_button.Ok | standard_button.Cancel)

        self.format_combo.addItems(["PNG", "JPG"])
        self.quality_spin.setRange(1, 100)
        self.quality_spin.setValue(90)
        self.summary_label.setWordWrap(True)

        directory_layout = QHBoxLayout()
        directory_layout.addWidget(self.directory_field)
        directory_layout.addWidget(self.browse_button)

        form = QFormLayout()
        form.addRow("Folder:", directory_layout)
        form.addRow("Format:", self.format_combo)
        form.addRow("JPG quality:", self.quality_spin)

        layout = QVBoxLayout(self)
        layout.addWidget(self.summary_label)
        layout.addLayout(form)
        layout.addWidget(self.button_box)

        self.browse_button.clicked.connect(self.select_directory)
        self.format_combo.currentTextChanged.connect(self.update_quality_state)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        self.update_quality_state()

    def select_directory(self):
        directory = FileDialog.getExistingDirectory(self, "Select Export Folder", os.path.expanduser("~"))
        if directory:
            self.directory_field.setText(directory)

    def update_quality_state(self):
        self.quality_spin.setEnabled(self.format_combo.currentText() == "JPG")


class SelectedLayerExporter(Extension):
    def setup(self):
        pass

    def createActions(self, window):
        action = window.createAction("selected_layer_exporter", "Export Selected Layers...")
        action.setToolTip("Export selected image layers as PNG or JPG.")
        action.triggered.connect(self.show_dialog)

    def show_dialog(self):
        app = self.parent()
        window = app.activeWindow()
        view = window.activeView() if window else None
        document = app.activeDocument()

        if not document or not view:
            QMessageBox.warning(None, "Export Selected Layers", "Open a document and select layers first.")
            return

        nodes = [node for node in view.selectedNodes() if node.type() in EXPORTABLE_TYPES]
        if not nodes:
            QMessageBox.warning(
                None,
                "Export Selected Layers",
                "No exportable image layers are selected.",
            )
            return

        dialog = ExportDialog()
        dialog.summary_label.setText("{} selected image layer(s) will be exported.".format(len(nodes)))
        accepted = enum_value(QDialog, "DialogCode", "Accepted")
        if dialog.exec() != accepted:
            return

        directory = dialog.directory_field.text()
        if not directory:
            QMessageBox.warning(dialog, "Export Selected Layers", "Select an export folder.")
            return

        os.makedirs(directory, exist_ok=True)
        fmt = dialog.format_combo.currentText()
        quality = dialog.quality_spin.value()

        exported = []
        errors = []
        canceled = False
        progress = QProgressDialog("Preparing export...", "Cancel", 0, len(nodes), dialog)
        progress.setWindowTitle("Export Selected Layers")
        progress.setWindowModality(enum_value(Qt, "WindowModality", "ApplicationModal"))
        progress.setMinimumDuration(0)
        progress.setValue(0)
        QApplication.processEvents()

        batch_mode = Application.batchmode()
        Application.setBatchmode(True)
        try:
            for index, node in enumerate(nodes, start=1):
                if progress.wasCanceled():
                    canceled = True
                    break

                progress.setLabelText(
                    "Exporting {}/{}: {}".format(index, len(nodes), node.name())
                )
                progress.setValue(index - 1)
                QApplication.processEvents()

                try:
                    path = self.export_node(document, node, directory, fmt, quality, index)
                    exported.append(path)
                except Exception as exc:
                    errors.append("{}: {}".format(node.name(), exc))

                progress.setValue(index)
                QApplication.processEvents()
        finally:
            Application.setBatchmode(batch_mode)
            progress.close()

        if canceled:
            QMessageBox.information(
                dialog,
                "Export Selected Layers",
                "Canceled after exporting {} layer(s).".format(len(exported)),
            )
        elif errors:
            QMessageBox.warning(
                dialog,
                "Export Selected Layers",
                "Exported {} layer(s), but {} failed:\n{}".format(
                    len(exported), len(errors), "\n".join(errors[:8])
                ),
            )
        else:
            QMessageBox.information(
                dialog,
                "Export Selected Layers",
                "Exported {} layer(s).".format(len(exported)),
            )

    def export_node(self, document, node, directory, fmt, quality, index):
        bounds = node.bounds()
        width = max(1, bounds.width())
        height = max(1, bounds.height())
        base_name = "{:03d}_{}".format(index, sanitize_filename(node.name()))
        extension = ".png" if fmt == "PNG" else ".jpg"
        path = unique_path(directory, base_name, extension)
        rect = QRect(bounds.x(), bounds.y(), width, height)
        x_res = document.resolution() / 72.0
        y_res = document.resolution() / 72.0

        image_format = enum_value(QImage, "Format", "Format_ARGB32")
        rgb_format = enum_value(QImage, "Format", "Format_RGB32")

        if fmt == "PNG":
            node.save(path, x_res, y_res, InfoObject(), rect)
        else:
            handle, temp_path = tempfile.mkstemp(suffix=".png")
            os.close(handle)
            try:
                node.save(temp_path, x_res, y_res, InfoObject(), rect)
                image = QImage(temp_path)
                if image.isNull():
                    raise RuntimeError("Could not read temporary PNG.")
                image = image.convertToFormat(image_format)
            finally:
                if os.path.exists(temp_path):
                    os.remove(temp_path)

            canvas = QImage(width, height, rgb_format)
            canvas.fill(QColor(255, 255, 255))
            painter = QPainter(canvas)
            painter.drawImage(0, 0, image)
            painter.end()
            if not canvas.save(path, "JPG", quality):
                raise RuntimeError("Could not save JPG.")

        return path
