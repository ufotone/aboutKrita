import krita

from .selected_layer_exporter import SelectedLayerExporter


Scripter.addExtension(SelectedLayerExporter(krita.Krita.instance()))
