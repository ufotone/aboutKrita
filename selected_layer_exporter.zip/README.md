# Selected Layer Exporter for Krita 5+

Kritaで選択中の画像レイヤーを、指定フォルダへPNGまたはJPGで一括書き出しするPythonプラグインです。

- PNG: アルファあり
- JPG: 白背景に合成してアルファなし
- 対象: paint/group/file/vector/fill/clone layer

## インストール

1. Kritaを閉じます。
2. このフォルダ内の以下2つを、Kritaの`pykrita`フォルダへコピーします。
   - `kritapykrita_selected_layer_exporter.desktop`
   - `selected_layer_exporter`
3. Kritaを起動し、`設定 > Kritaの設定 > Pythonプラグインマネージャー`で`Selected Layer Exporter`を有効化します。
4. Kritaを再起動します。

Windowsのユーザー用配置先は通常以下です。

```text
%APPDATA%\krita\pykrita
```

全ユーザー向けに本体側へ置く場合は以下です。

```text
C:\Program Files\Krita (x64)\share\krita\pykrita
```

## 使い方

1. レイヤーパネルで書き出したいレイヤーを複数選択します。
2. メニューから`Tools > Scripts > Export Selected Layers...`を実行します。
3. フォルダ、形式、JPG品質を選んでOKを押します。
